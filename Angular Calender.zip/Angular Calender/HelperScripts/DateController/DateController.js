﻿///<reference path="../../Scripts/angular.js" />
///<reference path="../../Scripts/angular.animate" />
///<reference path="../../Scripts/angular-ui/ui-bootstrap-tpls-js" />
///<reference path="../../Scripts/angular-ui/ui-bootstrap.js" />

(function () {

    var app = angular.module("appDate", []);

    var dateController = function ($scope) {
        $scope.selectedStartDate = '';
        $scope.selectedEndDate = '';
        $scope.minStartDate = '15/01/2016';
        //$scope.disableDays = ["0", "4"];
        //$scope.disableDays = [];
        //$scope.disableDates = ["17/01/2016", "25/01/2016", "02/02/2016", "17/04/2016", "25/03/2016", "02/04/2016"];        
        $scope.onStartDateSet = function (date) {
            $scope.selectedStartDate = date;
            //Do something..anything
        }
        $scope.onEndDateSet = function (date) {
            $scope.selectedEndDate = date;
        }
    }
    app.controller("DateController", dateController);
}());