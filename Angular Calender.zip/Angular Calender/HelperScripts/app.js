﻿///<reference path="Scripts/angular.js" />
///<reference path="Scripts/angular.animate" />
///<reference path="Scripts/angular-ui/ui-bootstrap-tpls-js" />
///<reference path="Scripts/angular-ui/ui-bootstrap.js" />

(function () {
    var app = angular.module("appDate", []);
}());